import{_ as ce,r as v,o as me,c as y,b as o,d as l,w as a,e as i,F as I,E as p,h as m,q as P,a5 as ve,i as n,g as M,v as _,a6 as ge,t as r,a2 as fe,m as w,x as ye}from"./index-BJCnv84f.js";import{u as _e}from"./user-D4Ix4s0D.js";import{p as be}from"./patient-Be7b9qle.js";import{i as W}from"./request-CQs8HcZH.js";import{h as xe}from"./html2pdf-CMUOxSy4.js";import"./index-BLRFddlS.js";import"./index-t--hEgTQ.js";import"./jspdf.es.min-UoPoTODO.js";const he=T=>W.get("/eeg/analysis",{params:T}),we=T=>W.get("/eeg/analysisList",{params:T}),ke={class:"eeg-container"},Ce={class:"section-header"},Fe={class:"header-left"},Te={class:"analysis-section"},$e={class:"section-header"},Ee={class:"pagination"},Le={class:"section-header"},Ne={key:0,class:"analysis-loading"},Se={key:1,class:"analysis-results"},ze={class:"result-item"},Ie={class:"result-item"},Pe={class:"result-item"},De={key:0,class:"result-item"},Ve={key:0,class:"record-detail"},Re={class:"detail-section"},Ue={class:"detail-section"},Be={class:"anomaly-tags"},Me={class:"dialog-footer"},Ae="/api/eeg/upload",Oe={__name:"Eeg",setup(T){const $=v(!1),E=v(!1),d=v(null);v("");const k=v({id:"",username:"",name:"",email:"",createTime:"",updateTime:""}),J=async()=>{try{const t=await _e();k.value=t.data,console.log(k.value.id)}catch(t){console.error("获取用户信息失败:",t)}},b=v(""),K=async()=>{try{const t=await be();A.value=t.data}catch(t){console.error("获取患者失败:",t)}},A=v([]),u=v(null),D=v(""),L=v(1),N=v(10),O=v(0),V=v([]),X=t=>{const e=t.name.toLowerCase().endsWith(".edf")||t.name.toLowerCase().endsWith(".eeg"),C=t.size/1024/1024<500;return e?C?b.value===""?(p.warning("请先选择病人"),!1):!0:(p.error("文件大小不能超过 500MB!"),!1):(p.error("请上传EDF或EEG格式的文件!"),!1)},Y=t=>{p.success("文件上传成功")},Z=()=>{p.error("文件上传失败")},ee=async()=>{if(b.value===""){p.warning("请选择病人");return}$.value=!0,u.value=null;try{let t={patientId:b.value,userId:k.value.id},e=await he(t);u.value=e.data.data,p.success("分析完成"),S()}catch(t){p.error("分析失败："+t.message)}finally{$.value=!1}},G=t=>t>70?"#F56C6C":t>30?"#E6A23C":"#67C23A",te=t=>typeof t=="number"?t>70?"danger":t>30?"warning":"success":t==="high"?"danger":t==="medium"?"warning":"success",R=t=>typeof t=="number"?t>70?"高风险":t>30?"中等风险":"低风险":{high:"高风险",medium:"中等风险",low:"低风险"}[t]||"未知",le=()=>{if(!u.value){p.warning("暂无可导出的分析结果");return}const e={date:new Date().toLocaleDateString("zh-CN"),patientInfo:"患者信息",results:u.value,doctor:"主治医生"};console.log("导出报告数据:",e),p.success("报告导出中...")},q=t=>{if(!t){p.warning("记录数据不完整");return}try{const e=document.createElement("div");e.className="pdf-container",e.style.padding="20px",e.style.fontFamily="Arial, sans-serif",e.innerHTML=`
      <div style="text-align: center; margin-bottom: 20px;">
        <h1 style="color: #409EFF;">${t.patientName}的EEG分析报告</h1>
        <p>检测日期: ${t.createTime}</p>
      </div>
      
      <div style="margin-bottom: 20px;">
        <h2>患者信息</h2>
        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td style="border: 1px solid #ddd; padding: 8px; width: 30%;">患者姓名</td>
            <td style="border: 1px solid #ddd; padding: 8px;">${t.patientName}</td>
          </tr>
          <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">患者ID</td>
            <td style="border: 1px solid #ddd; padding: 8px;">${t.patientId}</td>
          </tr>
        </table>
      </div>
      
      <div style="margin-bottom: 20px;">
        <h2>分析结果</h2>
        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td style="border: 1px solid #ddd; padding: 8px; width: 30%;">风险等级</td>
            <td style="border: 1px solid #ddd; padding: 8px;">${R(t.riskLevel)} (${t.riskLevel}%)</td>
          </tr>
          <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">脑电节律</td>
            <td style="border: 1px solid #ddd; padding: 8px;">${t.rhythm||"未知"}</td>
          </tr>
          <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">异常放电次数</td>
            <td style="border: 1px solid #ddd; padding: 8px;">${t.dischargeCount||0}</td>
          </tr>
          <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">主要频段</td>
            <td style="border: 1px solid #ddd; padding: 8px;">${t.frequency||"未知"}</td>
          </tr>
        </table>
      </div>
      
      <div style="margin-bottom: 20px;">
        <h2>异常波形</h2>
        <ul>
          ${t.anomalies&&t.anomalies.length>0?t.anomalies.map(g=>`<li>${g.type} (${g.severity==="warning"?"警告":g.severity==="danger"?"危险":"信息"})</li>`).join(""):"<li>未检测到异常波形</li>"}
        </ul>
      </div>
      
      <div style="margin-bottom: 20px;">
        <h2>文件信息</h2>
        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td style="border: 1px solid #ddd; padding: 8px; width: 30%;">文件名</td>
            <td style="border: 1px solid #ddd; padding: 8px;">${t.fileName||"未知"}</td>
          </tr>
          <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">文件大小</td>
            <td style="border: 1px solid #ddd; padding: 8px;">${t.fileSize?(t.fileSize/1024/1024).toFixed(2)+" MB":"未知"}</td>
          </tr>
          ${t.startTime!==void 0&&t.endTime!==void 0?`
          <tr>
            <td style="border: 1px solid #ddd; padding: 8px;">发作时间段</td>
            <td style="border: 1px solid #ddd; padding: 8px;">${t.startTime}s - ${t.endTime}s</td>
          </tr>`:""}
        </table>
      </div>
      
      <div style="margin-top: 40px; text-align: right;">
        <p>分析医生: ${t.doctorName||"未知"}</p>
        <p>生成日期: ${new Date().toLocaleDateString("zh-CN")}</p>
      </div>
    `,document.body.appendChild(e);const C={margin:10,filename:`${t.patientName}EEG分析报告_${t.createTime.split(" ")[0].replace(/-/g,"")}.pdf`,image:{type:"jpeg",quality:.98},html2canvas:{scale:2,useCORS:!0},jsPDF:{unit:"mm",format:"a4",orientation:"portrait"}};xe().from(e).set(C).save().then(()=>{document.body.removeChild(e),p.success(`已导出 ${t.patientName} 的检查记录`)}).catch(g=>{console.error("PDF导出失败:",g),p.error("PDF导出失败: "+g.message),document.body.contains(e)&&document.body.removeChild(e)})}catch(e){console.error("导出失败:",e),p.error("导出失败: "+e.message)}},ae=t=>{if(!t){p.warning("记录数据不完整");return}try{d.value=t,E.value=!0}catch(e){console.error("查看记录失败:",e),p.error("查看记录失败: "+e.message)}};v([{label:"FP1-F7",value:"FP1-F7"},{label:"F7-T3",value:"F7-T3"},{label:"T3-T5",value:"T3-T5"},{label:"T5-O1",value:"T5-O1"},{label:"FP2-F8",value:"FP2-F8"},{label:"F8-T4",value:"F8-T4"},{label:"T4-T6",value:"T4-T6"},{label:"T6-O2",value:"T6-O2"},{label:"FP1-F3",value:"FP1-F3"},{label:"F3-C3",value:"F3-C3"},{label:"C3-P3",value:"C3-P3"},{label:"P3-O1",value:"P3-O1"}]);const se=t=>{N.value=t,S()},oe=t=>{L.value=t,S()},S=async()=>{try{const t={pageNum:L.value,pageSize:N.value,searchQuery:D.value,patientId:b.value,userId:k.value.id},e=await we(t);console.log(e),V.value=e.data.items,console.log(V.value),O.value=e.data.total}catch(t){p.error("查询失败:"+t.message)}};return me(()=>{K(),J(),S()}),(t,e)=>{const C=i("el-option"),g=i("el-select"),z=i("el-icon"),x=i("el-button"),ne=i("el-upload"),U=i("el-card"),de=i("el-input"),h=i("el-table-column"),B=i("el-tag"),re=i("el-table"),ie=i("el-pagination"),j=i("el-col"),H=i("el-progress"),c=i("el-descriptions-item"),F=i("el-descriptions"),Q=i("el-empty"),ue=i("el-row"),pe=i("el-dialog");return m(),y(I,null,[o("div",ke,[l(U,{class:"upload-section"},{header:a(()=>[o("div",Ce,[o("div",Fe,[e[7]||(e[7]=o("span",null,"EEG数据分析",-1)),l(g,{modelValue:b.value,"onUpdate:modelValue":e[0]||(e[0]=s=>b.value=s),clearable:"",placeholder:"选择病人",style:{"margin-left":"20px",width:"240px"}},{default:a(()=>[(m(!0),y(I,null,M(A.value,s=>(m(),_(C,{key:s.name,label:s.name,value:s.id},null,8,["label","value"]))),128))]),_:1},8,["modelValue"])]),l(x,{type:"primary",onClick:ee,loading:$.value},{default:a(()=>[l(z,null,{default:a(()=>[l(P(ge))]),_:1}),e[8]||(e[8]=n(" 开始分析 "))]),_:1},8,["loading"])])]),default:a(()=>[l(ne,{class:"eeg-upload",drag:"",action:Ae,"before-upload":X,"auto-upload":!0,"on-success":Y,"on-error":Z,accept:".edf,.eeg",data:{patientId:b.value,userId:k.value.id}},{tip:a(()=>e[9]||(e[9]=[o("div",{class:"el-upload__tip"}," 支持.edf/.eeg格式文件，单个文件不超过500MB ",-1)])),default:a(()=>[l(z,{class:"el-icon--upload"},{default:a(()=>[l(P(ve))]),_:1}),e[10]||(e[10]=o("div",{class:"el-upload__text"},[n(" 拖拽EEG文件到此处或 "),o("em",null,"点击上传")],-1))]),_:1},8,["data"])]),_:1}),o("div",Te,[l(ue,{gutter:20},{default:a(()=>[l(j,{span:16},{default:a(()=>[l(U,{class:"history-section"},{header:a(()=>[o("div",$e,[e[11]||(e[11]=o("span",null,"分析历史",-1)),l(de,{modelValue:D.value,"onUpdate:modelValue":e[1]||(e[1]=s=>D.value=s),placeholder:"搜索患者姓名","prefix-icon":"Search",style:{width:"200px"}},null,8,["modelValue"])])]),default:a(()=>[l(re,{data:V.value,style:{width:"100%"}},{default:a(()=>[l(h,{prop:"createTime",label:"检测日期",width:"180"}),l(h,{prop:"patientName",label:"患者姓名",width:"120"}),l(h,{prop:"patientId",label:"患者ID",width:"120"}),l(h,{prop:"riskLevel",label:"风险等级",width:"120"},{default:a(s=>[l(B,{type:te(s.row.riskLevel)},{default:a(()=>[n(r(R(s.row.riskLevel)),1)]),_:2},1032,["type"])]),_:1}),l(h,{prop:"doctorName",label:"分析医生",width:"120"}),l(h,{label:"操作"},{default:a(s=>[l(x,{link:"",type:"primary",onClick:f=>ae(s.row)},{default:a(()=>e[12]||(e[12]=[n(" 查看 ")])),_:2},1032,["onClick"]),l(x,{link:"",type:"primary",onClick:f=>q(s.row)},{default:a(()=>e[13]||(e[13]=[n(" 导出 ")])),_:2},1032,["onClick"])]),_:1})]),_:1},8,["data"]),o("div",Ee,[l(ie,{"current-page":L.value,"onUpdate:currentPage":e[2]||(e[2]=s=>L.value=s),"page-size":N.value,"onUpdate:pageSize":e[3]||(e[3]=s=>N.value=s),"page-sizes":[10,20,50,100],layout:"total, sizes, prev, pager, next",total:O.value,onSizeChange:se,onCurrentChange:oe},null,8,["current-page","page-size","total"])])]),_:1})]),_:1}),l(j,{span:8},{default:a(()=>[l(U,{class:"result-card"},{header:a(()=>[o("div",Le,[e[15]||(e[15]=o("span",null,"分析结果",-1)),l(x,{type:"primary",link:"",onClick:le},{default:a(()=>[l(z,null,{default:a(()=>[l(P(ye))]),_:1}),e[14]||(e[14]=n(" 导出报告 "))]),_:1})])]),default:a(()=>[$.value?(m(),y("div",Ne,[l(z,{class:"loading-icon"},{default:a(()=>[l(P(fe))]),_:1}),e[16]||(e[16]=o("p",{class:"loading-text"},"正在分析...",-1)),e[17]||(e[17]=o("p",{class:"loading-text"},"(因文件涉及上传下载，请耐心等待)",-1))])):u.value?(m(),y("div",Se,[o("div",ze,[e[18]||(e[18]=o("div",{class:"result-label"},"癫痫发作风险评估",-1)),l(H,{percentage:u.value.riskLevel,color:G},null,8,["percentage"])]),o("div",Ie,[e[19]||(e[19]=o("div",{class:"result-label"},"异常波形检测",-1)),(m(!0),y(I,null,M(u.value.anomalies,(s,f)=>(m(),_(B,{key:f,type:s.severity,class:"anomaly-tag"},{default:a(()=>[n(r(s.type),1)]),_:2},1032,["type"]))),128))]),o("div",Pe,[e[20]||(e[20]=o("div",{class:"result-label"},"关键指标",-1)),l(F,{column:1,border:""},{default:a(()=>[l(c,{label:"脑电节律"},{default:a(()=>[n(r(u.value.rhythm),1)]),_:1}),l(c,{label:"异常放电次数"},{default:a(()=>[n(r(u.value.dischargeCount),1)]),_:1}),l(c,{label:"主要频段"},{default:a(()=>[n(r(u.value.frequency),1)]),_:1})]),_:1})]),u.value.file_name?(m(),y("div",De,[e[21]||(e[21]=o("div",{class:"result-label"},"文件信息",-1)),l(F,{column:1,border:""},{default:a(()=>{var s,f;return[l(c,{label:"文件名"},{default:a(()=>[n(r(u.value.file_name),1)]),_:1}),l(c,{label:"文件大小"},{default:a(()=>[n(r((u.value.file_size/1024/1024).toFixed(2))+" MB ",1)]),_:1}),((s=u.value)==null?void 0:s.start_time)!==0&&((f=u.value)==null?void 0:f.end_time)!==0?(m(),_(c,{key:0,label:"发作时间段"},{default:a(()=>[n(r(u.value.start_time)+"s - "+r(u.value.end_time)+"s ",1)]),_:1})):w("",!0)]}),_:1})])):w("",!0)])):(m(),_(Q,{key:2,description:"暂无分析结果"}))]),_:1})]),_:1})]),_:1})])]),l(pe,{modelValue:E.value,"onUpdate:modelValue":e[6]||(e[6]=s=>E.value=s),title:"EEG分析详情",width:"80%","destroy-on-close":!0},{footer:a(()=>[o("span",Me,[l(x,{onClick:e[4]||(e[4]=s=>E.value=!1)},{default:a(()=>e[24]||(e[24]=[n("关闭")])),_:1}),l(x,{type:"primary",onClick:e[5]||(e[5]=s=>q(d.value))},{default:a(()=>e[25]||(e[25]=[n(" 导出PDF ")])),_:1})])]),default:a(()=>[d.value?(m(),y("div",Ve,[l(F,{title:"患者信息",column:2,border:""},{default:a(()=>[l(c,{label:"患者姓名"},{default:a(()=>[n(r(d.value.patientName),1)]),_:1}),l(c,{label:"患者ID"},{default:a(()=>[n(r(d.value.patientId),1)]),_:1}),l(c,{label:"检测日期"},{default:a(()=>[n(r(d.value.createTime),1)]),_:1}),l(c,{label:"分析医生"},{default:a(()=>[n(r(d.value.doctorName),1)]),_:1})]),_:1}),o("div",Re,[e[22]||(e[22]=o("h3",null,"风险评估",-1)),l(H,{percentage:d.value.riskLevel,color:G(d.value.riskLevel),format:()=>R(d.value.riskLevel)},null,8,["percentage","color","format"])]),o("div",Ue,[e[23]||(e[23]=o("h3",null,"异常波形检测",-1)),o("div",Be,[(m(!0),y(I,null,M(d.value.anomalies,(s,f)=>(m(),_(B,{key:f,type:s.severity,class:"anomaly-tag"},{default:a(()=>[n(r(s.type),1)]),_:2},1032,["type"]))),128)),!d.value.anomalies||d.value.anomalies.length===0?(m(),_(Q,{key:0,description:"未检测到异常波形"})):w("",!0)])]),l(F,{title:"关键指标",column:2,border:""},{default:a(()=>[l(c,{label:"脑电节律"},{default:a(()=>[n(r(d.value.rhythm||"未知"),1)]),_:1}),l(c,{label:"异常放电次数"},{default:a(()=>[n(r(d.value.dischargeCount||0),1)]),_:1}),l(c,{label:"主要频段"},{default:a(()=>[n(r(d.value.frequency||"未知"),1)]),_:1})]),_:1}),d.value.fileName?(m(),_(F,{key:0,title:"文件信息",column:2,border:""},{default:a(()=>[l(c,{label:"文件名"},{default:a(()=>[n(r(d.value.fileName),1)]),_:1}),l(c,{label:"文件大小"},{default:a(()=>[n(r(d.value.fileSize?(d.value.fileSize/1024/1024).toFixed(2)+" MB":"未知"),1)]),_:1}),d.value.startTime!==void 0&&d.value.endTime!==void 0?(m(),_(c,{key:0,label:"发作时间段"},{default:a(()=>[n(r(d.value.startTime)+"s - "+r(d.value.endTime)+"s ",1)]),_:1})):w("",!0)]),_:1})):w("",!0)])):w("",!0)]),_:1},8,["modelValue"])],64)}}},Xe=ce(Oe,[["__scopeId","data-v-2cd7c828"]]);export{Xe as default};
