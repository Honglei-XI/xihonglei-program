const s="/assets/%E8%99%9A%E6%8B%9F%E5%BD%A2%E8%B1%A1-min-DcV3wpH1.gif";export{s as _};
